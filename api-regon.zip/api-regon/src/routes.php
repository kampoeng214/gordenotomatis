<?php

use Slim\Http\Request;
use Slim\Http\Response;

// Routes


$app->get('/[{name}]', function (Request $request, Response $response, array $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});


$app->get("/login/", function(Request $request, Response $response){
    
        $username = $request->getQueryParam("username");
        $password = md5($request->getQueryParam("password"));
        
        $sql = "SELECT * FROM tb_user WHERE username = '$username' AND password = '$password'";
        $stmt = $this->db->prepare($sql);
    $data = [
    	":username" => $username,
    	":password" => $password
    ];
    $stmt->execute($data);
    $result = $stmt->fetchALL();
    $row = $stmt->rowCount();
    if($row > 0){
        return $response->withJson(["status" => "success", "data" => $result], 200);
    }else{
         return $response->withJson(["status" => "failed", "data" => null], 200);
    }
});

$app->get("/monitoring/", function(Request $request, Response $response){
    try{
        $sql = "SELECT * FROM tb_monitoring ORDER BY id_monitoring";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchALL();
        return $response->withJson(["status" => "success", "data" => $result], 200);
    } catch (Exception $e){
        return $response->withJson(["status" => "failed", "alert" => "Error"], 200);
    }
});